#include <QApplication>
#include <QTextStream>
#include <QLibrary>
#include "xldownloader.h"

/*
LONG XL_CreateTaskByThunder(wchar_t *pszUrl, wchar_t *pszFileName, wchar_t *pszReferUrl, wchar_t *pszCharSet, wchar_t *pszCookie)

[in] pszUrl，任务URL
[in] pszFileName，下载保存的文件名
[in] pszReferUrl，引用页URL
[in] pszCharSet，当前网页的字符集
[in] pszCookie，下载数据所需的cookie

*/

typedef bool (*XLinit)(void);//定义函数指针，以备调用
typedef long (*XLdownloader)(const wchar_t *pszUrl, const wchar_t *pszFileName, wchar_t *pszReferUrl, wchar_t *pszCharSet, wchar_t *pszCookie);
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    XLDownloader mainwindow;
    mainwindow.setWindowTitle("使用QT调用迅雷下载demo程序");
    mainwindow.show();
    return a.exec();
}
