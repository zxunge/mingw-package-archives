#ifndef XLDOWNLOADER_H
#define XLDOWNLOADER_H

#include <QWidget>
#include <QTextStream>
#include <QLibrary>
#include <QUrl>
#include "ui_xldownloader.h"
namespace Ui {
class XLDownloader;
}

class XLDownloader : public QWidget
{
    Q_OBJECT

public:
    explicit XLDownloader(QWidget *parent = 0);
    ~XLDownloader();

private:
    Ui::XLDownloader *ui;
    typedef bool (*XLinit)(void);//定义迅雷下载初始化函数指针类型
    XLinit xlinit; //初始化函数
    typedef long (*XLdownloader)(const wchar_t *pszUrl, const wchar_t *pszFileName, wchar_t *pszReferUrl, wchar_t *pszCharSet, wchar_t *pszCookie);//定义迅雷下载 下载文件函数指针类型
    XLdownloader xldownloader;//下载文件函数


    QTextStream qcout;
    bool initXunLei()
    {
        QLibrary mylib("./ThunderOpenSDK/xldl.dll");   //声明所用到的dll文件
        if (mylib.load())
        {
            qcout<<"load xldl.dll sucess"<<endl;
            xlinit=(XLinit)mylib.resolve("XL_Init");    //援引 add() 函数
            bool retflag=xlinit();
             if (retflag==false)
             {
                 qcout<<"initialize thunder failed"<<endl;
                 return false;
             }
             else
             {
                 qcout<<"initialize thunder sucess"<<endl;
                 xldownloader=(XLdownloader)mylib.resolve("XL_CreateTaskByThunder");
                 return true;
             }
        }
        else
        {
            qcout<<"load xldl.dll failed"<<endl;
            return false;
        }
    }

    bool downloadWithXL(QString url,QString filename)
    {
         const wchar_t *xlurl=reinterpret_cast< const wchar_t *>(url.utf16());

         const wchar_t *xlfn=reinterpret_cast< const wchar_t *>(filename.utf16());

        long retdown=xldownloader(xlurl,xlfn,NULL,NULL,NULL);
        if (retdown==0)
        {
             qcout<<"add thunder task sucess"<<endl;
             return true;
        }
        else
        {

            qcout<<"add thunder task failed"<<endl;
            return false;
        }

    }

private slots:
       void onClickedDownloadButton()
       {

        QString url= ui->lineEdit->text();//用户在输入url时，一定要输入http:// ,后面可以添加让程序自己判断部分
        QUrl qurl(url);

        QString filename=qurl.fileName();
        //qcout<<"filename is "<<filename<<endl;
        if(filename.isEmpty())
        {
            filename="index.html";
        }
        //qcout<<"filename is "<<filename<<endl;
        //return ;
        if(!url.isEmpty())
        downloadWithXL(url,filename);
       }


};

#endif // XLDOWNLOADER_H
