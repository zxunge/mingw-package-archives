#include "xldownloader.h"
#include "ui_xldownloader.h"

XLDownloader::XLDownloader(QWidget *parent) :
    QWidget(parent),qcout(stdout),
    ui(new Ui::XLDownloader)
{
    ui->setupUi(this);
    bool XLflag=initXunLei();
    if (!XLflag)
        exit(1);

    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(onClickedDownloadButton()));
}

XLDownloader::~XLDownloader()
{
    delete ui;
}
